import React from 'react'

const Notefound = () => {
  return (
    <div className='notfound_container'>
      <div>
        <img  style={{ borderRadius: "10px",width:"80%",marginTop:"3rem" }} src="https://media.licdn.com/dms/image/C5612AQEPYce5KpNLyg/article-cover_image-shrink_720_1280/0/1551659700811?e=2147483647&v=beta&t=O9mBMiF-V12jCRJwaBNDWLKNL8cku2QSoCXtKP3vCHg" alt="not_found" />
      </div>
    </div>
  )
}

export default Notefound